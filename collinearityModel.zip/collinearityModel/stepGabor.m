%% / Step function for the Gabor layer
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
% Small helper function to filter an image with a Gabor kernel. The Gabor kernel is not calculated here for speed reasons, but should be rather provided to this function. 
% It is intended to define the Gabor kernel beforehand (see function gaborKernel.m).
% 
%% Notes:
% - This version processes a grayscale image.
%
%\
% Copyright/License: Copyright 2022-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
%
%> @param  img      Image (grayscale)
%> @param  kernel   Gabor kernel
%> @return rG       Gabor response
function rG = stepGabor(img, kernel)

   rG = conv2(img, kernel, 'same');
   
   rG(rG<0) = 0;

end
