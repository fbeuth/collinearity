%% / Readme
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
% @mainpage 
% This repository contains the source code for the following publication:
% Beuth and Kowerko (2025). "On the Transfer of Collinearity to Computer Vision". 
%
% Author(s):
% Frederik Beuth (Dr. Frederik Beuth, beuth@cs.tu-chemnitz.de).
%
% Source code documentation collinearity model: <a href="../BeuthKowerko2025.pdf">BeuthKowerko2025.pdf</a>: <a href="../BeuthKowerko2025.pdf">BeuthKowerko2025.pdf</a>
%\

