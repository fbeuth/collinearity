%% / Main file of the collinearity model
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
%
%% @details  
% Idea of the model:
% - Processes an image with Gabor filtering
% - Pooling
% - Calculating collinearity connectivity on top
%
%\
% Copyright/License: Copyright 2022-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
function main()

   %% Parameters
   resultDir = './results';    % Result directory. Results will be automatically saved in this directory.
  
   % Orientations - for Gabor and for collinearity
   orientations = [0:pi/4:1.75*pi]; % Edge orientations

   % Strength of the image, image values can be downscaled via this parameter
   imgStrength = 1;

   %% Define stimulus setups
   % inputfile  -> Input image
   % kernelSize -> Size of the Gabor. This is the kernel size, but it automatically scales also f and sigma to match it. 
   %   Thus, this parameter controls also the Gabor's the spatial frequency.
   % lambdaPx   -> How many pixels are 1 lambda, regarding the collinearity range mechanism. Separate variable to 
   %   allow fine-tuning, more control.
   
   % Three example stimulus setups:
   % Setup 1 - Small stimulus
   %inputfile = '../data/test1.png';
   %kernelSize = 5;
   %lambdaPx = 2;
   
   % Setup 2 - Middle-sized stimulus
   %inputfile = '../data/test2.png';
   %kernelSize = 11;   
   %lambdaPx = 11; 
   
   % Setup 3 - Real sized stimulus
   inputfile = 'data/test5.png';
   kernelSize = 11;   
   lambdaPx = 11; 
   
   % Strength of the collinearity influence
   wC = 0.8;
   
   % For ODE system: End time
   tEnd = 100;     
   
   % Pooling factor of Gabor pooling stage
   poolFactor = 3;
   
   % Fontsizes, and colors, markers of the plot
   labelSize = 14;
   titleSize = 17;
   colors = [0.2863 0.4392 0.6627; 
      0.3922    0.5294    0.3333;
      0.9020    0.7843    0.3255];
   
   
   %% Source code
   %% Initialization and loading the image
   addpath('matlabLibs');
   if (exist(resultDir, 'dir') == 0)
      mkdir(resultDir)
   end
      
   % Load input image  
   imgRGB = imread(inputfile);
   imgRGB = double(imgRGB)/255;
   img = rgb2gray(imgRGB);
   img = img * imgStrength;
   
   % Sizes
   resImg = size(img);
   resRG = [resImg, numel(orientations)];
   resPooled = [floor(resRG(1:2)./poolFactor), resRG(3)];
   resRC = [resPooled(1:2), numel(orientations)];
   
   
   %% --- Calculate collinearity model ---
   %% Gabor layer
   rG = zeros(resRG);
   
   % Gabor parameters
   f = 1/kernelSize;                         % Frequency of the Gabor
   sigma1 = kernelSize/3;                    % Sigma_1. Sigma is chosen to discretize the Gauss in a window +-1.5sigma
   sigma2 = 4*sigma1;                        % Sigma_2 is the sigma in direction of the elongation of the Gabor (alone the edge). Choosen as 4 times of sigma_1.
   halfSDsq = [1/( 2*sigma1^2), 1/( 2*sigma2^2)]; % Precalculated term: 1/(2*SD^2)
   psi = -pi/2;                              % Phase shift of the Gabor

   % Loop over orientations
   for o = 1:numel(orientations)
      theta = orientations(o);               % Orientation
      
      % Define Gabor kernel
      kernel = gaborKernel(kernelSize, halfSDsq, theta, f, psi);  % Gabor kernel for single orientation
      kernels(:,:,o) = kernel;                                    % Gabor kernels for all orientations
      
      % Normalization factor of the Gabor kernel
      k1 = kernel;
      k1(k1<0) = 0;
      v = sum(k1(:)); % Normalize to sum of positive parts of the kernel == 1
      kernel = kernel./v;
      
      % Calculate responses
      rG(:,:,o) = stepGabor(img, kernel);
   end
   
   % Nullify edges of the image
   % - The Gabor response is invalid on the borders of the image, thus we handle it by nullifing the Gabor responses.
   rfh = (kernelSize-1)/2; % Receptive field - half.
   rG(1:rfh,:,:) = 0;
   rG(:,1:rfh,:) = 0;
   rG(end-rfh:end,:,:) = 0;
   rG(:,end-rfh:end,:) = 0;
   
   %% Pooling layer
   % Pool the Gabors layer responses
   % Lanczos3 kernel pooling
   rGpool = zeros(resPooled);        
   
   for l = 1:resPooled(3)
      rGpool(:,:,l) = imresize(rG(:,:,l), resPooled(1:2), 'lanczos3');
   end
   rGpool(rGpool<0) = 0;
   rGpool(rGpool>1) = 1;
   
   % Auto-scaling
   % - Automatically scale responses up
   % - Scaling should be done at level of V1pooled as the lanczos3 filter has small inaccurancies in the height, and
   %   the scaling would be inaccurate if applied to V1 directly. The values for the scaling are anyway determined at
   %   v1pooled as these are the responses going to the next layer
   %scal = 1.78;   % Scale factor. For natural/real-world scenes. See Beuth (2019).
   %scal = 1.2;    % Scale factor. For scenes with artificial stimuli. See Beuth (2019).
   scal = 1.40;    % Scale factor. For current demonstrator
   rGpool = rGpool * scal;   
   
   %% Collinearity Layer 
   % Calculate collinearity responses
   rC = zeros(resRC);
   showRCMax = zeros(tEnd,1);  % Variable to record responses over simulation time if needed
   for t = 1:tEnd
      rC = stepCollinearity(rGpool, orientations, (lambdaPx/poolFactor), rC, t, wC);      
      showRCMax(t) = max(rC(:));
   end
    
   
   %% Plotting and illustrations
   
   % The Y and X coordinates of the cells' responses that are plotted
   ySliceImg = 74;       % Y-coordinate, in image size coordinates
   xPosition = 201;      % X-coordinate, in image size coordinates
   ySlice = 77;          % Y-coordinate, in V1 size coordinates
   ySlicePool = 26;      % Y-coordinate, in V1 pool size coordinates
   xPositionPool = 66;   % X-coordinate, in V1 pool size coordinates

   papersize = [0,0,30,20]; 
   figure('visible', 'on', 'Paperposition', papersize, 'PaperSize', papersize([3:4]));
   subx=4;
   suby=2;
   
   % Plot input image
   subplot(suby, subx, 1);
   imagesc(img, [0,1]);
   set(gca, 'Fontsize', labelSize);
   title('Image', 'Fontsize', titleSize);
   colormap gray
   axis image
   
   % Plot Gabor kernels
   subplot(suby, subx, 2);
   % Display kernels with inverted axis, due to the convolution-function (conv2.m).
   K = flip(flip(kernels, 1), 2);
   imagesc3(K);
   set(gca, 'Fontsize', labelSize);
   title('Gabor kernels', 'Fontsize', titleSize);
   
   % Plot Gabor layer
   subplot(suby, subx, 3);
   imagesc(montage3(rG, 12), [0,max(rG(:))]);
   set(gca, 'Fontsize', labelSize);
   title('Response Gabor Layer', 'Fontsize', titleSize);
   axis off;
   
   % Plot Gabor layer - zoom into a single orientation
   subplot(suby, subx, 5);
   imagesc(rG(:,:,1), [0,max(rG(:))]);
   set(gca, 'Fontsize', labelSize);
   title('   Response Gabor -\newline horizontal orientation', 'Fontsize', titleSize);
   
   % Draw also a marker (electrode) to show the position of the plotted neuron
   hold on
   hElectrode = drawTriangle(xPosition, ySlice, colors(1,:), [200,75]);
   
   % Plot Collinearity layer
   subplot(suby, subx, 6);
   imagesc(montage3(rC, 3), [0,max(rC(:))]);
   set(gca, 'Fontsize', labelSize);
   title('Response Collinearity\newline          Layer', 'Fontsize', titleSize);
   axis off;
   
   % Plot Collinearity layer - zoom into a single orientation
   subplot(suby, subx, 7);
   imagesc(rC(:,:,1), [0,max(rC(:))]);
   set(gca, 'Fontsize', labelSize);
   title('Response Collinearity -\newline horizontal orientation', 'Fontsize', titleSize);
   
   % Draw also an electrode to mark recording position
   hold on
   hElectrode = drawTriangle(xPositionPool, ySlicePool, colors(2,:), [66.6,25]); % [75,25]
   
   % Plot Collinearity layer responses as bar plot   
   A = rGpool(ySlicePool, xPositionPool, 1); 
   B = rC(ySlicePool, xPositionPool, 1);
   subplot(suby, subx, 8);
   hbar1 = bar([A; B], 'BarWidth', 0.3);
   set(gca, 'Fontsize', labelSize);
   title('Response Collinearity', 'Fontsize', titleSize);
   % - Set colors
   hbar1.FaceColor = 'flat';
   hbar1.CData(1,:) = colors(1,:);
   hbar1.CData(2,:) = colors(2,:);
   set(gca, 'Xticklabel', {'No Collinearity', 'Collinearity'});
   xlim([0.5,2.5]);
   
   % Plot model figure
   subplot(suby, subx, 4);
   M = imread('./data/modelFigure.png');
   imagesc(M);
   title('Model', 'Fontsize', titleSize);
   axis image;
   axis off;
   
   
   %% Saving results
   % - Save it as .png with same filename as the input image
   % - In the result folder
   tmp = strsplit(inputfile, '/');
   filename = tmp{end};
   filenameNoExtension = filename(1:end-4);
   
   resultFile = sprintf('%s/%s.png', resultDir, filenameNoExtension);
   print(resultFile, '-dpng', '-r225');  
   
   fprintf('Done\n');
         
end
