%% / Calculates the collinearity layer responses
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
% This function calculates the collinearity layer and its responses. It is performed for a single time step of the 
% ordinary differential equation system (ODE), denoted step function.
% 
% Idea:
% - Collinearity in 8 orientations. The number of orientation is variable, 8 is just the often used value.
% - This function calculates 1 timestep, i.e. it should run in a loop. (This is a step function)
% - Calculation is performed via convolution with a kernel, simulating the lateral weights. Lateral weights are weights that take place within the same layer.
% - The complicated part is to calculate the lateral weights pattern. This is done by the function calculateCollinearityKernel() 
%   for a given orientation, see below.
%
% Weight pattern is based on psychological/neuroscience (psychophysical) data:
% - Weights are now modeled based on the psychophysical data from Maniglia et al. (2015)
% - For <=  4 lambda, the weight is 0
% - For >= 14 lambda, the weight is 0
% - The data shows a decrease between 12 and 14 lambda, I assume a linear degrees since it fits the data. 
%   Thus, weights linearly decrease 12 and 14 lambda.
% - The authors measure at 4 degree retinal eccentricity, and for a 1 degree Gabor (1 cycle per degree, 1 cpd).
% 
% Weight pattern is also according to data from Kapadia et al. (2000): 
% - Kernel is according to tilt data of Kapadia et al. (2000) showing a certain spatial width of the influence pattern. 
%   Assumed is a width of 1 stimulus (roughly 2 lambda).
% - Note: It needs to be decreases if pooling is used. 
% 
% Implementation:
% - This is the fourth revision of the collinearity layer model
% - Creating a width for an rotating line is a nightmare with the geometry. Due to this, this source code is 
%   re-implemented and I found a better trick. I create the line (more a bar) and use then the function imrotate() to rotate the bar! 
% - Much easier implementation.
% - It only works if the line is wide enough because otherwise you have discretization errors, hence optimally for a line 
%   with minimum width of 3. 
% - Steps:
%   - 1) Generate horizontally-aligned kernel
%   - 2) Rotate the kernel for the intended orientation
%
% References:
% - Maniglia, M., Pavan, A., Aedo-Jury, F., & Trotter, Y. (2015). The spatial range of peripheral collinear facilitation. 
%   Scientific Reports, 5(1), 15530. 
% - Kapadia, M.K., Westheimer, G., & Gilbert, C.D. (2000). Spatial Distribution of Contextual Interactions in Primary 
%   Visual Cortex and in Visual Perception. Journal of Neurophysiology, 84(4), 2048–2062.
%\
% Copyright/License: Copyright 2022-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
%
%> @param  rG       Gabor layer response
%> @param  orientations Which orientations, in rad (0..2pi)
%> @param  lambdaPx How many pixels are 1 lambda. Independent parameter to allow fine-tuning/debugging.
%> @param  rC_old   Collinearity layer responses, of the previous timestep t-1
%> @param  t        Current timestep
%> @param  wC       Lateral weight scalar for connection rC -> rC. Parameter is implicit the strength of the collinearity. 
%>                  Optional parameter, standard value is 1.0.
%> @param  width    Width of the kernel in pixels. Optional parameter, default value is 2 lambdaPx.
%> @return rC       Collinearity layer responses, of current timestep t
function rC = stepCollinearity(rG, orientations, lambdaPx, rC_old, t, wC, width)

   %% Parameters
   resRC = size(rC_old);
   tauC = 15;     % Tau for collinearity ODE, in ms
   wrg = 1.0;     % Feedforward weight scalar for connection rG -> rC
   if(nargin<6)
      wC  = 1.0;  % Lateral weight scalar for connection rC -> rC   
   end
   if(nargin<7)
      width  = lambdaPx*2; % Width of the kernel in pixels. Separate parameter from lambda to have more control.
   end
   

   %% Source code
   rC = zeros(resRC);
   
   % Loop over orientations
   for o = 1:numel(orientations)
      
      % Calculate collinearity kernel
      K = calculateCollinearityKernel(orientations(o), lambdaPx, width);
      
      % Normalize kernel to sum=1
      % Update: normalize kernel to sum over the total lengths == 1. Since the kernel is #width wide, 
      % it implies the sum of the kernel is == #width.
      % - It also implicitly assumes that over the width, roughly only a single cell is active
      K = K ./ sum(K(:)) * width;
      
      % Do the convolution
      % - 'Same' -> padding with zeros. 
      %   If we need something else, we would need an explicit extension of rC layer
      % - curN = response neighbors
      curN = conv2(rC_old(:,:,o), K, 'same'); 
      
      % ODE
      rC(:,:,o) = rC_old(:,:,o) + 1./tauC * ( -rC_old(:,:,o) + wrg*rG(:,:,o) .*(1 + wC*curN));
	  
   end % [orientations]
   
end


%% > And a small helper function to calculate the kernel for the collinearity connections
% - Kernel is at max. 2*14 lambda
% - Connections are lateral (lateral = side-wise, or within the same layer)
% - Lateral connection consists of a line going in the direction of the orientation
% - Only weights are set > 4 lambda && <= 14 lambda
%
%@param orientation  The orientation of the connections, in 0 ... 2pi. 0 denotes the horizontal orientation.
%@param lambdaPx     How many pixels are 1 lambda.
%@param width        Width of the kernel in pixels.
function kernel = calculateCollinearityKernel(orientation, lambdaPx, width)   
   
   %% Initial definitions
   % Update after Maniglia et al., 2015
   % Assume at maximum, we need 2*14*lambdaPx x 2*14*lambdaPx kernelsize, i.e. if the orientation is 0,90,180,270°   
   kernelsize = ceil(14*lambdaPx*2);   
   
   % Kernel is always odd. Force an odd kernel
   if(rem(kernelsize, 2) == 0)
      kernelsize = kernelsize + 1;
   end
   
   kernel = zeros(kernelsize, kernelsize);
  
   %% Generate horizontal-aligned kernel
   cen = (kernelsize-1)/2 + 1;    % cen = center of the kernel / kernel size half
   dy = round((width-1)/2);       % y extent on each line side, currently in total 1 lambda. In width.
   
   % Updated version based on data from Maniglia et al., 2015
   % - No weights with <= 4 lambda && >= 14 lambda
   % - Between 12 and 14 lambda, linear interpolation i.e. linearly decreasing weights 
   x = 1:kernelsize;           
   for i=1:kernelsize
      dist = abs(cen-x(i)); % Distance from center
      if(dist <= 12*lambdaPx && dist > 4.5*lambdaPx)
         kernel(cen-dy:cen+dy, x(i)) = 1;                             % <- for until 12 lambda constant weights
      elseif(dist > 12*lambdaPx && dist <= 14*lambdaPx)
         kernel(cen-dy:cen+dy, x(i)) = - (dist/lambdaPx - 12)/2 + 1;  % <- after 12 lambda linear decreasing weights
      end
   end
   
   %% Rotate kernel for intended orientation
   kernel = imrotate(kernel, orientation/pi*180, 'bilinear', 'crop');   
    
end
