%% / Visualise 4D data as a 2D matrix.
% @authors beuth, nick (Nikolay.Chumerin@med.kuleuven.be)
%
% - Should be used as "imagesc(montage4(x))".
%\
%> @param  inp    The data.
%> @param  border Optional border width, standard value is 2.
%> @return out      A 2D array, which can be nicely shown via imagesc, illustrating the data.
function out = montage4(inp, border)
    if ~exist('border', 'var') || isempty(border)
        border = 2;
    end
    
    [rows cols mrows mcols] = size(inp);
    
    out = nan(border+(rows+border)*mrows, border+(cols+border)*mcols);    % unified data representation
    used = false(border+(rows+border)*mrows, border+(cols+border)*mcols); % true if out is uded, false if it indicate a border
    
    for r = 1:mrows,
        for c = 1:mcols,
            out(border+(rows+border)*(r-1) + (1:rows), border+(cols+border)*(c-1) + (1:cols)) = inp(:,:,r,c);
            used(border+(rows+border)*(r-1) + (1:rows), border+(cols+border)*(c-1) + (1:cols)) = true;
        end
    end
    % set borders to mean
    maxV = max(inp(:));
    minV = min(inp(:));
    if(maxV>minV)
       out(~used) = mean([maxV,minV]);
    else
       out(~used) = maxV*0.99;
    end
end
