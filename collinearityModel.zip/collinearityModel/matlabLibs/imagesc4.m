%% > Visualise 4D data as a 2D plot (see montage4.m)
%>@author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
%> @param  inp    The data.
%> @param  cRange Optional color range for the underlying imagesc.
%> @return h      Handle to the created image object.
% Copyright/License: Copyright 2016-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
function h = imagesc4(inp, cRange)
   if(nargin<2)
      h = imagesc(montage4(inp));
   else
      h = imagesc(montage4(inp), cRange);
   end
end
