%% / Visualise 3D data as a 2D matrix.
% @authors beuth, nick (Nikolay.Chumerin@med.kuleuven.be)
%
% - Should be used as "imagesc(montage3(x))".
%\
%> @param  inp    The data.
%> @param  border Optional border width, standard value is 2.
%> @return out      A 2D array, which can be nicely shown via imagesc, illustrating the data.
function out = montage3(inp, border)
    if ~exist('border', 'var') || isempty(border)
        border = 2;
    end
    
    [rows cols mrows0] = size(inp);
    mcols = ceil(sqrt(mrows0));
    mrows = ceil(mrows0 / mcols);
    
    out = zeros(border+(rows+border)*mrows, border+(cols+border)*mcols);  % unified data representation
    used = false(border+(rows+border)*mrows, border+(cols+border)*mcols); % true if out is uded, false if it indicate a border
    
    d = 0;
    for r = 1:mrows,
        for c = 1:mcols,
            d = d + 1;
            if(d<=mrows0)
               out(border+(rows+border)*(r-1) + (1:rows), border+(cols+border)*(c-1) + (1:cols)) = inp(:,:,d);
               used(border+(rows+border)*(r-1) + (1:rows), border+(cols+border)*(c-1) + (1:cols)) = true;
            end
        end
    end
    % set borders to mean
    maxV = max(inp(:));
    minV = min(inp(:));
    if(maxV>minV)
       out(~used) = mean([maxV,minV]);
    else
       out(~used) = maxV*0.99;
    end
end
