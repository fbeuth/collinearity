%% / Function to draw a triangle as a marker for the recording position
% The triangle symbolizes an electrode.
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
%% Notes:
% - A triangle can be drawn via the Matlab patch() function.
%
%\
% Copyright/License: Copyright 2022-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
%
%>@param x0    Offset in x-dimension
%>@param y0    Offset in y-dimension
%>@param color Color of the triangle
%>@param scale Scaling in X- and Y-direction
%>@return h    Handle of the triangle
function h = drawTriangle(x0, y0, color, scale)

   %% Parameters
   % Some default parameters for testing
   if(nargin<3)
      color = [0.3922    0.5294    0.3333];
   end
   if(nargin<4) 
      scale = [1, 1];
   end
   
   
   %% Sourcecode
   % Define coordinates of the triangle
   x = [0.0, -0.03, -0.1];
   y = -[0, 0.2676, 0.25];
   % Note: calculated coordinate for y(2): y(2) = 0.267581

   x = x*scale(1)+x0;
   y = y*scale(2)+y0;
   
   % Select colors
   edgeColor = color;
   faceColor = color*1.5;
   faceColor(faceColor>1.0) = 1.0;
   
   %Another option to select colors
   %edgeColor = 0.7*color;
   %faceColor = color;   
   
   hold on
   h = patch('XData', x, 'YData', y, 'EdgeColor', edgeColor, 'FaceColor', faceColor, 'Linewidth', 1);
   
end

%% Appendix - equations to calculate y(2)
% - c_1 = sqrt(a^2+b^2)
% - c_2 = c_1
% - c_2^2 = d^2+e^2
%   e^2 = c_2^-d^2
%   e = sqrt(c_2^-d^2)
