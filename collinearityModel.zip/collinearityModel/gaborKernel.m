%% / Generate 2D Gabor kernel
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
% - @f$ G\left(x,x0, \sigma,f,\psi \right) =  \exp \left(-\frac{(x'_1-x0_1)^2}{2\sigma}   + \frac{(x'_2-x0_2)^2}{2 \sigma} \right) \cdot \cos \left(2 \pi f x_1' + \psi \right) @f$
% - @f$ x_1' = x_1 \cos \theta + x_2 \sin \theta @f$
% - @f$ x_2' = x_1 \sin \theta + x_2 \cos \theta @f$
% - The version also works with different sigma_1 and sigma_2.
% - For an alternative description of the above equation via complex numbers see Javier R. Movellan (Gabor tutorial).
% - The parameter "spatialCompression" shrinks the Y/X dimension of the filter. For example if spatialCompression=[2,1],
%   you get a discretization windows of "kernelSize", but the Gabor function itself has only 50% width in y-dimension, 
%   the rest of the kernel is zero.
% - Standard normalization is: @f$ (1/\sqrt{2 \pi \sigma_X}) \cdot (1/\sqrt{2 \pi \sigma_Y}) @f$
%\
% Copyright/License: Copyright 2014-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
%
%> @param kernelSize  The size of the envelop.
%> @param halfSDsq    Pre calculated term: @f$ \frac{1}{2 \sigma^2} @f$ (2x1)
%> @param theta       Orientation.
%> @param f           Spatial frequency
%> @param psi         Phase shift.
%> @param spatialCompression Spatial compression(y,x) of the input space in Y/X direction of the kernel (optional)
%> @retval K          2D Gabor kernel
function K = gaborKernel(kernelSize, halfSDsq, theta, f, psi, spatialCompression)

    %% Parameter
    % To demonstrate the function, or for debugging purpose
    testing = 0;
    if(nargin < 1)
        testing = 1;
    end
    
    % Optionally, compress the input space
    if(nargin < 6)
       spatialCompression = [1,1];
    end
    assert(spatialCompression(1)>=1);
    assert(spatialCompression(2)>=1);
    
    %% Sourcecode
    if(testing == 1)
        %RGB
        %filename = 'test1.png';
        %img = rgb2gray(imread(filename));
        
        theta = 0; % Orientation
        psi = 0*-pi/4; % Phase shift of a Gabor
        f = 0.25*1/11;
        
        %hard coded filter properties
        kernelSize = 11;        
        halfSDsq = [1/( 2 * 3^2), 1/( 2 * 3^2)]; % Standard derivation sd = 3
        
    elseif(testing == 2) 
        %filename = 'test1.png';
        %img = rgb2gray(imread(filename));
        
        %theta = -pi/4;%orientation
        theta = 0;
        psi = -pi/2; % Phase shift of a Gabor
        
        kernelSize = 11;
        f = 1/kernelSize;
        halfSDsq = [1/( 2 * 3^2), 1/( 2 * 12^2)]; %sigma  = 3
    end    
    
    assert(numel(halfSDsq)==2);
    

    % Some terms for the Gabor equation
    twopiF = 2 * pi *f; 
    theta = theta + pi/2;
    
    % Calculate grids (calculation points) for receptive field
    a       = (kernelSize-1)/2; % Half support upper boundary
    [X,Y]   = meshgrid(-a:a, a:-1:-a);
    % Spatial compression is applied by compressing the coordinate system
    X = spatialCompression(2)*X;
    Y = spatialCompression(1)*Y;
    XT1      = 1*((X)  .* cos(theta) + Y.*sin(theta));
    YT1      = 1*(Y.*cos(theta) - (X) .* sin(theta));
    
    % Receptive Field (RF)
    % Standard normalization is: 1/sqrt(2*pi*sigmaX) *  1/sqrt(2*pi*sigmaY)
    K = exp( - halfSDsq(1)*(XT1.*XT1) - halfSDsq(2)*YT1.*YT1) .* cos(twopiF*XT1 + psi);
    
    % DC Correction
    % Source: Arash Kermani / Fred Hamker
    if(cos(psi)>0.001 || cos(psi)<-0.001)
       Gaussian = exp( - halfSDsq(1)*(XT1.*XT1) - halfSDsq(2)*YT1.*YT1);
       Gabor = Gaussian .* cos(twopiF*XT1 + psi);
       DC = Gaussian/mean(Gaussian(:))*mean(Gabor(:));
       K = Gabor  - DC;
    end       
        
    % If we have spatial compression, set values outside the function to 0
    if(spatialCompression(2) > 1)
       setX = floor((kernelSize * (1-1/spatialCompression(2)))/2);
       if(setX>0)
         K(:,1:setX) = 0;
         K(:,kernelSize-setX+1:kernelSize) = 0;
       end
    end
    if(spatialCompression(1) > 1)
       setX = floor((kernelSize * (1-1/spatialCompression(1)))/2);
       if(setX>0)
          K(1:setX, :) = 0;
          K(kernelSize-setX+1:kernelSize, :) = 0;
       end
    end
       
    if(testing ~= 0)
        figure
        colormap gray

        imagesc(K);
        axis image;
        title('Kernel');        
    end
    
end
