%% / Experiment to evaluate the variable length of the line
% @author Frederik Beuth (beuth@cs.tu-chemnitz.de)
%
%% @details 
% Generates a tuning curve depending on the length of the line
% - We change the length of the line in pixel (px)
%
% Structure of the model:
% - Processes an image with Gabor filtering
% - Pooling
% - Calculating collinearity connectivity on top
%\
% Copyright/License: Copyright 2022-2025, Frederik Beuth; Apache 2.0, see LICENSE for details.
function experimentLineLength()

   %% Parameters
   resultDir = './resultsLineLength'; % Result directory. Results will be automatically saved in this directory.
   
   % Fontsizes, and colors, markers of the plot
   labelSize = 22;
   titleSize = 24;
   colors = [0.2863 0.4392 0.6627; 
      0.3922    0.5294    0.3333;
      0.9020    0.7843    0.3255];
   
   % Orientations - for Gabor and for collinearity
   orientations = [0:pi/4:1.75*pi]; % Edge orientations
 
   % Define stimulus setups
   % inputfile  -> Input stimulus
   % kernelSize -> Size of the Gabor. This is the kernel size, but it automatically scales also f and sigma to match it. Thus, this parameter
   %   controls the spatial frequency
   % lambdaPx   -> How many pixels are 1 lambda, regarding the collinerity range mechanism. Separate variable to allow fine-tuning, more control

   kernelSize = 11;
   lambdaPx = 5;

   wC = 1.0;    % Strength of collinearity
   width = 1;   % Width of the collinearity kernel
   
   % For ODE system: End time
   tEnd = 100;
   
   % Pooling factor of Gabor pooling stage
   poolFactor = 1;

   % How long should be the line - generate length levels
   % Fast version
   %lineLengths = 20:20:200;
   % Normal version
   lineLengths = [13, 20:10:200];
   L = numel(lineLengths);


   %% Source code
   if (exist(resultDir, 'dir') == 0)
      mkdir(resultDir)
   end
   addpath('matlabLibs');

     
   %% Generate input  
   % Define image
   img = zeros(20,200);

   % Store sizes
   resImg = size(img);
   resRG = [resImg, numel(orientations)];
   resPooled = [floor(resRG(1:2)./poolFactor), resRG(3)];
   resRC = [resPooled(1:2), numel(orientations)];

   imgAll = cell(L);                         % All input images recorded   
   rG_length = zeros([L,1]);                 % Response of Gabors at recorded position at different length levels
   rC_length = zeros([L,1]);                 % Response of Collinearity at recorded position at different length level
   rG_lengthSlice = zeros([L,resPooled(2)]); % Response of Gabors at a slice at different length levels
   rC_lengthSlice = zeros([L,resRC(2)]);     % Response of Collinearity at a slice at different length levels


   %% --- Calculate collinearity model ---   
   %% Define Gabor kernels
   % - Define it at the beginning as they are the same for each experiment run
   Ks = cell(numel(orientations), 1);        % List of Gabor kernels

   % Gabor parameters
   f = 1/kernelSize;                         % Frequency
   sigma1 = kernelSize/3;                    % Sigma_1. Sigma is chosen to discretize the Gauss in a window +-1.5sigma
   sigma2 = 4*sigma1;                        % Sigma_2 is the sigma in direction of the elongation of the Gabor (along the edge). It is choosen as 4 times of sigma_1.
   halfSDsq = [1/( 2*sigma1^2), 1/( 2*sigma2^2)]; % Precalculated term: 1/(2*SD^2)
   psi = -pi/2;                              % Phase shift of a Gabor

   % Loop over orientations
   for o = 1:numel(orientations)
      theta = orientations(o);               % Orientation

      kernel = gaborKernel(kernelSize, halfSDsq, theta, f, psi);  % Gabor kernel for single orientation
      kernels(:,:,o) = kernel;                                    % Gabor kernels for all orientations, for showing

      % Normalization factor
      k1 = kernel;
      k1(k1<0) = 0;
      v = sum(k1(:)); % Normalize to sum positive parts of kernel == 1

      Ks{o} = kernel ./ v;
   end

   %% Experiment loop
   % Loop over all experiments, i.e. over all line lengths
   for l = 1:L

      %% Generate input line
      img = zeros(resImg);
      border = floor((resImg(2)-lineLengths(l)) / 2);  % Distance from the image border where the line begins
      img(5:15, border+1:end-border) = 0.5;           % Line illumination level

      %% Gabor Layer responses
      rG = zeros(resRG);
      % Loop over orientations
      for o = 1:numel(orientations)      
         rG(:,:,o) = stepGabor(img, Ks{o});
      end
      
      %% Pooling Layer
      % - Lanczos3 kernel pooling
      rGpool = zeros(resPooled);        

      % No pooling/1x1 pooling (poolFactor==1).
      if(poolFactor == 1)         
         rGpool = rG;
         
      % Pooling
      else
         for o = 1:resPooled(3)
            rGpool(:,:,o) = imresize(rG(:,:,o), resPooled(1:2), 'lanczos3');
         end
         rGpool(rGpool<0) = 0;
         rGpool(rGpool>1) = 1;
         
         % Scaling
         scal = 1.2;   % Auto-Scale factor.
         rGpool = rGpool * scal;
      end
      

      %% Collinearity Layer
      % Calculate collinearity responses
      rC = zeros(resRC);
      showRCMax = zeros(tEnd,1);        
      for t = 1:tEnd
         rC = stepCollinearity(rGpool, orientations, (lambdaPx/poolFactor), rC, t, wC, width); 
         showRCMax(t) = max(rC(:));
      end

      %% Record responses
      imgAll{l} = img;

      rG_length(l) = rGpool(5,101,1);
      rC_length(l) = rC(5,101,1);

      rG_lengthSlice(l,:) = rGpool(5,:,1);
      rC_lengthSlice(l,:) = rC(5,:,1);

      % Experiment counter
      disp(lineLengths(l));
   end
      

   %% Plotting the line length tuning curve
   papersize = [-0.6125    6.5156   20.50   16.6687];
   h1 = figure('Paperposition', papersize);
   plot(lineLengths, rG_length, '+-', 'Color', colors(1,:), 'markersize', 8, ...
      'linewidth', 2);
   hold on
   plot(lineLengths, rC_length, 'o-', 'Color', colors(2,:), 'markersize', 8, ...
      'linewidth', 2);
   ylabel('Response', 'fontsize', labelSize);
   xlabel('Line length in px', 'fontsize', labelSize);
   set(gca, 'fontsize', labelSize);
   title('Length of line', 'fontsize', titleSize);
   legend({'No collinearity', 'With collinearity'}, 'fontsize', titleSize, ...
      'location', 'southeast');
   ylim([0,1]);
   set(gca, 'Ytick', [0:0.2:1]);
   
   %% Plot some selected lengths also as slices
   h2 = figure('Paperposition', [-0.6125    6.5156   20.50   16.6687]);
   plot([rC_lengthSlice(6,:); rC_lengthSlice(10,:); rC_lengthSlice(16,:)]', ...
      'linewidth', 2);
   ylabel('Neural response', 'fontsize', labelSize);
   xlabel('Spatial position in px', 'fontsize', labelSize);
   set(gca, 'fontsize', labelSize);   
   title('Line length slices', 'fontsize', titleSize);
   legend({sprintf('Length %0.2f', lineLengths(6)), ...
      sprintf('Length %0.2f', lineLengths(10)), ...
      sprintf('Length %0.2f', lineLengths(16))}, 'fontsize', titleSize);
   ylim([0,1]);
   set(gca, 'Ytick', [0:0.2:1]);   
   
   
   %% Save
   if(exist(resultDir, 'dir') == 0)
      mkdir(resultDir);
   end
   % Save image (normal and as high-resolution(HQ))
   % - Use a middle contrasted image
   img = imgAll{6};
   savefile = sprintf('%s/lineLengthImage.png', resultDir);
   imwrite(img, savefile);
   imgHQ = imresize(img, 3, 'lanczos3');
   imgHQ(imgHQ<0) = 0;
   imgHQ(imgHQ>1) = 1;
   savefile = sprintf('%s/lineLengthImageHQ.png', resultDir);
   imwrite(imgHQ, savefile);  
   
   % Save line-length tuning curve
   savefile = sprintf('%s/lineLengthTuningcurve.png', resultDir);
   print(h1, savefile, '-dpng', '-r225');  
   savefile = sprintf('%s/lineLengthTuningcurve.fig', resultDir);
   saveas(h1, savefile, 'fig');

   savefile = sprintf('%s/lineLengthSlice.png', resultDir);
   print(h2, savefile, '-dpng', '-r225');  
   savefile = sprintf('%s/lineLengthSlice.fig', resultDir);
   saveas(h2, savefile, 'fig');
   
   fprintf('Finished\n');
   
end
